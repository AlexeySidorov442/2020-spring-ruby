# frozen_string_literal: true

require_relative 'models/input_validators'
require_relative 'models/book'
require_relative 'models/book_list'
