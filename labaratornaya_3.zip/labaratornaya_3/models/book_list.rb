# frozen_string_literal: true

Book = Struct.new(:name, :date, :description)
